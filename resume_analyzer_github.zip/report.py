"""
PDF/CSV report generation.
"""

import os
import csv
from datetime import datetime


class ReportGenerator:
    def __init__(self):
        self.output_dir = "reports"
        os.makedirs(self.output_dir, exist_ok=True)

    def generate_pdf_report(self, match_result, resume_data, suggestions) -> str:
        try:
            from fpdf import FPDF

            pdf = FPDF()
            pdf.add_page()

            pdf.set_font("Arial", "B", 20)
            pdf.cell(0, 15, "Smart Resume Analyzer - Report", ln=True, align="C")

            pdf.set_font("Arial", "", 10)
            pdf.cell(
                0,
                8,
                f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
                ln=True,
            )
            pdf.ln(5)

            pdf.set_font("Arial", "B", 16)
            pdf.cell(0, 10, "Overall Match Score", ln=True)
            pdf.set_font("Arial", "B", 30)
            pdf.cell(0, 15, f"{match_result.overall_score:.1f}%", ln=True, align="C")
            pdf.ln(5)

            pdf.set_font("Arial", "B", 14)
            pdf.cell(0, 10, "Candidate Information", ln=True)
            pdf.set_font("Arial", "", 11)
            pdf.cell(0, 7, f"Name: {resume_data.name or 'Not provided'}", ln=True)
            pdf.cell(0, 7, f"Email: {resume_data.email or 'Not provided'}", ln=True)
            pdf.cell(0, 7, f"Phone: {resume_data.phone or 'Not provided'}", ln=True)
            pdf.ln(5)

            pdf.set_font("Arial", "B", 14)
            pdf.cell(0, 10, "Component Scores", ln=True)
            pdf.set_font("Arial", "", 11)
            pdf.cell(80, 7, "Skills Match:")
            pdf.cell(0, 7, f"{match_result.skills_match_score:.1f}%", ln=True)
            pdf.cell(80, 7, "Semantic Similarity:")
            pdf.cell(0, 7, f"{match_result.semantic_similarity_score:.1f}%", ln=True)
            pdf.cell(80, 7, "Experience Relevance:")
            pdf.cell(0, 7, f"{match_result.experience_relevance_score:.1f}%", ln=True)
            pdf.cell(80, 7, "Education Match:")
            pdf.cell(0, 7, f"{match_result.education_match_score:.1f}%", ln=True)
            pdf.cell(80, 7, "Resume Quality:")
            pdf.cell(0, 7, f"{match_result.resume_quality_score:.1f}%", ln=True)
            pdf.ln(5)

            pdf.set_font("Arial", "B", 14)
            pdf.cell(0, 10, "Skills Analysis", ln=True)
            pdf.set_font("Arial", "", 11)
            pdf.cell(
                0,
                7,
                f"Matched ({len(match_result.matched_skills)}): {', '.join(match_result.matched_skills[:10])}",
                ln=True,
            )
            pdf.cell(
                0,
                7,
                f"Missing ({len(match_result.missing_skills)}): {', '.join(match_result.missing_skills[:10])}",
                ln=True,
            )

            pdf.ln(5)
            pdf.set_font("Arial", "B", 14)
            pdf.cell(0, 10, "Suggestions", ln=True)
            pdf.set_font("Arial", "", 10)
            for i, s in enumerate(suggestions[:10], 1):
                pdf.multi_cell(0, 6, f"{i}. [{s.priority}] {s.message}")
                pdf.multi_cell(0, 6, f"   Action: {s.action_item}")
                pdf.ln(2)

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"resume_report_{timestamp}.pdf"
            filepath = os.path.join(self.output_dir, filename)
            pdf.output(filepath)
            return filepath
        except Exception as e:
            print(f"PDF generation failed: {e}")
            import traceback

            traceback.print_exc()
            return None

    def generate_csv_report(self, match_result, resume_data, suggestions) -> str:
        try:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"resume_report_{timestamp}.csv"
            filepath = os.path.join(self.output_dir, filename)

            with open(filepath, "w", newline="", encoding="utf-8") as csvfile:
                writer = csv.writer(csvfile)
                writer.writerow(["Smart Resume Analyzer - Report"])
                writer.writerow(
                    [f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"]
                )
                writer.writerow([])
                writer.writerow(["CANDIDATE INFORMATION"])
                writer.writerow(["Name", resume_data.name or "Not provided"])
                writer.writerow(["Email", resume_data.email or "Not provided"])
                writer.writerow(["Phone", resume_data.phone or "Not provided"])
                writer.writerow([])
                writer.writerow(["SCORES"])
                writer.writerow(["Overall Score", f"{match_result.overall_score:.1f}%"])
                writer.writerow(
                    ["Skills Match", f"{match_result.skills_match_score:.1f}%"]
                )
                writer.writerow(
                    [
                        "Semantic Similarity",
                        f"{match_result.semantic_similarity_score:.1f}%",
                    ]
                )
                writer.writerow(
                    [
                        "Experience Relevance",
                        f"{match_result.experience_relevance_score:.1f}%",
                    ]
                )
                writer.writerow(
                    ["Education Match", f"{match_result.education_match_score:.1f}%"]
                )
                writer.writerow(
                    ["Resume Quality", f"{match_result.resume_quality_score:.1f}%"]
                )
                writer.writerow([])
                writer.writerow(["SKILLS ANALYSIS"])
                writer.writerow(
                    ["Matched Skills", ", ".join(match_result.matched_skills)]
                )
                writer.writerow(
                    ["Missing Skills", ", ".join(match_result.missing_skills)]
                )
                writer.writerow([])
                writer.writerow(["SUGGESTIONS"])
                writer.writerow(["Priority", "Category", "Message", "Action Item"])
                for s in suggestions:
                    writer.writerow([s.priority, s.category, s.message, s.action_item])

            return filepath
        except Exception as e:
            print(f"CSV generation failed: {e}")
            return None


def generate_report(match_result, resume_data, suggestions, format: str = "both"):
    generator = ReportGenerator()
    result = {}

    if format in ["pdf", "both"]:
        pdf_path = generator.generate_pdf_report(match_result, resume_data, suggestions)
        if pdf_path:
            result["pdf"] = pdf_path

    if format in ["csv", "both"]:
        csv_path = generator.generate_csv_report(match_result, resume_data, suggestions)
        if csv_path:
            result["csv"] = csv_path

    return result
