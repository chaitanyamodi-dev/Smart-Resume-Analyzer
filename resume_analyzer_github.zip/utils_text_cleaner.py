"""
Text cleaning and preprocessing utilities.
"""

import re
import unicodedata
from typing import List


def clean_text(text: str) -> str:
    """Clean and normalize extracted text from resumes."""
    if not text:
        return ""

    text = unicodedata.normalize("NFKD", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" {2,}", " ", text)
    text = re.sub(r"[^\w\s.,;:\-()@/]", "", text)

    lines = [line.strip() for line in text.split("\n")]
    text = "\n".join(line for line in lines if line)

    return text.strip()


def extract_emails(text: str) -> List[str]:
    """Extract email addresses from text."""
    email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
    emails = re.findall(email_pattern, text)
    return list(set(emails))


def extract_phones(text: str) -> List[str]:
    """Extract phone numbers from text."""
    phone_patterns = [
        r"\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}",
        r"\(\d{3}\)\s?\d{3}[-.]?\d{4}",
        r"\d{3}[-.]\d{3}[-.]\d{4}",
    ]

    phones = []
    for pattern in phone_patterns:
        phones.extend(re.findall(pattern, text))

    cleaned_phones = []
    for phone in phones:
        cleaned = re.sub(r"[^\d+]", "", phone)
        if len(cleaned) >= 10:
            cleaned_phones.append(cleaned)

    return list(set(cleaned_phones))


def extract_name(text: str) -> str:
    """Extract candidate name using heuristics."""
    lines = text.split("\n")[:10]

    for line in lines:
        line = line.strip()
        if not line or len(line) < 3:
            continue

        if re.match(r"^[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}$", line):
            exclude_words = ["resume", "curriculum", "vitae", "cv", "objective"]
            if not any(word in line.lower() for word in exclude_words):
                return line

    return ""


def normalize_skill_name(skill: str) -> str:
    """Normalize skill names for consistent matching."""
    abbreviations = {
        "js": "JavaScript",
        "ts": "TypeScript",
        "ml": "Machine Learning",
        "dl": "Deep Learning",
        "nlp": "Natural Language Processing",
        "ai": "Artificial Intelligence",
    }
    return abbreviations.get(skill.lower().strip(), skill.title())
