"""
Feedback and improvement suggestions logic.
"""

from typing import List
from dataclasses import dataclass


@dataclass
class Suggestion:
    category: str
    priority: str
    message: str
    action_item: str


class SuggestionEngine:
    def generate_suggestions(self, match_result, resume_data) -> List[Suggestion]:
        suggestions = []

        # Skills-based suggestions
        if match_result.missing_skills:
            missing_count = len(match_result.missing_skills)
            suggestions.append(
                Suggestion(
                    category="Skills",
                    priority="High" if missing_count > 3 else "Medium",
                    message=f"You're missing {missing_count} key skills required for this role.",
                    action_item=f"Consider adding experience with: {', '.join(match_result.missing_skills[:5])}",
                )
            )

        if match_result.skills_match_score < 50:
            suggestions.append(
                Suggestion(
                    category="Skills",
                    priority="High",
                    message="Your skills match is below 50%. Consider upskilling.",
                    action_item="List projects or coursework where you used the missing technologies",
                )
            )

        # Experience-based suggestions
        has_numbers = False
        if resume_data.experience:
            for exp in resume_data.experience:
                desc = exp.get("description", "")
                if any(char.isdigit() for char in desc):
                    has_numbers = True
                    break

        if not has_numbers:
            suggestions.append(
                Suggestion(
                    category="Experience",
                    priority="High",
                    message="Your experience section lacks measurable achievements.",
                    action_item="Add metrics like 'Increased performance by 25%' or 'Reduced costs by $10K'",
                )
            )

        if (
            resume_data.experience
            and resume_data.experience[0].get("title") != "Not specified"
        ):
            total_desc_length = sum(
                len(exp.get("description", "")) for exp in resume_data.experience
            )
            if total_desc_length < 200:
                suggestions.append(
                    Suggestion(
                        category="Experience",
                        priority="Medium",
                        message="Your work experience descriptions are too brief.",
                        action_item="Expand each role with 3-5 bullet points",
                    )
                )

        # Action verbs check
        action_verbs = [
            "developed",
            "implemented",
            "designed",
            "created",
            "led",
            "managed",
            "optimized",
        ]
        has_action_verbs = False
        if resume_data.experience:
            for exp in resume_data.experience:
                desc = exp.get("description", "").lower()
                if any(verb in desc for verb in action_verbs):
                    has_action_verbs = True
                    break

        if not has_action_verbs:
            suggestions.append(
                Suggestion(
                    category="Experience",
                    priority="Medium",
                    message="Use strong action verbs to describe your experience.",
                    action_item="Start bullet points with: Developed, Implemented, Designed, Led, Optimized",
                )
            )

        # Format suggestions
        if not resume_data.name:
            suggestions.append(
                Suggestion(
                    category="Format",
                    priority="High",
                    message="Your name is not clearly visible.",
                    action_item="Add your full name prominently at the top",
                )
            )

        if not resume_data.email:
            suggestions.append(
                Suggestion(
                    category="Format",
                    priority="High",
                    message="Email address is missing.",
                    action_item="Add a professional email address in the header",
                )
            )

        if not resume_data.phone:
            suggestions.append(
                Suggestion(
                    category="Format",
                    priority="Medium",
                    message="Phone number is missing.",
                    action_item="Add your contact phone number",
                )
            )

        if not resume_data.summary:
            suggestions.append(
                Suggestion(
                    category="Format",
                    priority="Medium",
                    message="Missing professional summary.",
                    action_item="Add a 2-3 sentence summary highlighting your key qualifications",
                )
            )

        word_count = len(resume_data.raw_text.split())
        if word_count < 200:
            suggestions.append(
                Suggestion(
                    category="Format",
                    priority="High",
                    message="Your resume appears too short (less than 200 words).",
                    action_item="Add more details about your projects, skills, and experience",
                )
            )

        # ATS suggestions
        text_lower = resume_data.raw_text.lower()
        standard_sections = ["experience", "education", "skills", "projects"]
        missing_sections = [s.title() for s in standard_sections if s not in text_lower]

        if missing_sections:
            suggestions.append(
                Suggestion(
                    category="ATS Optimization",
                    priority="High",
                    message=f"Missing standard section headings: {', '.join(missing_sections)}",
                    action_item="Use clear headings like 'Work Experience', 'Education', 'Skills'",
                )
            )

        # Content suggestions
        generic_phrases = ["responsible for", "duties included", "worked on"]
        has_generic = any(
            phrase in resume_data.raw_text.lower() for phrase in generic_phrases
        )

        if has_generic:
            suggestions.append(
                Suggestion(
                    category="Content",
                    priority="Medium",
                    message="Resume contains generic phrases.",
                    action_item="Replace 'Responsible for X' with 'Achieved X by doing Y, resulting in Z'",
                )
            )

        # Sort by priority
        priority_order = {"High": 0, "Medium": 1, "Low": 2}
        suggestions.sort(key=lambda s: priority_order.get(s.priority, 3))

        return suggestions
