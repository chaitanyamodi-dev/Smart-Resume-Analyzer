"""
PDF and DOCX text extraction module.
"""

import os
from typing import Optional


class TextExtractor:
    def __init__(self):
        pass

    def extract_from_pdf(self, file_path: str) -> Optional[str]:
        """Extract text from PDF using pdfplumber or PyMuPDF."""
        text = None

        # Try pdfplumber first
        try:
            import pdfplumber

            text_parts = []
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text_parts.append(page_text)
            if text_parts:
                return "\n".join(text_parts)
        except Exception as e:
            print(f"pdfplumber failed: {e}")

        # Fallback to PyMuPDF
        try:
            import fitz

            doc = fitz.open(file_path)
            text_parts = []
            for page in doc:
                page_text = page.get_text()
                if page_text:
                    text_parts.append(page_text)
            doc.close()
            if text_parts:
                return "\n".join(text_parts)
        except Exception as e:
            print(f"PyMuPDF failed: {e}")

        return text

    def extract_from_docx(self, file_path: str) -> Optional[str]:
        """Extract text from DOCX file."""
        try:
            from docx import Document

            doc = Document(file_path)
            text_parts = []

            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text_parts.append(paragraph.text)

            for table in doc.tables:
                for row in table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            text_parts.append(cell.text)

            return "\n".join(text_parts) if text_parts else None
        except Exception as e:
            print(f"DOCX extraction failed: {e}")
            return None

    def extract_text(self, file_path: str) -> Optional[str]:
        """Auto-detect file type and extract text."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        _, ext = os.path.splitext(file_path)
        ext = ext.lower()

        if ext == ".pdf":
            return self.extract_from_pdf(file_path)
        elif ext == ".docx":
            return self.extract_from_docx(file_path)
        else:
            raise ValueError(f"Unsupported file format: {ext}")
