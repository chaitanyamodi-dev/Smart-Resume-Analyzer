"""
Entity and section parsing using regex and skills database.
"""

import re
import json
import os
from typing import Dict, List
from dataclasses import dataclass, field


@dataclass
class ResumeData:
    """Structured resume data."""

    name: str = ""
    email: str = ""
    phone: str = ""
    skills: List[str] = field(default_factory=list)
    education: List[Dict] = field(default_factory=list)
    experience: List[Dict] = field(default_factory=list)
    projects: List[Dict] = field(default_factory=list)
    summary: str = ""
    raw_text: str = ""


class ResumeParser:
    def __init__(self, skills_db_path: str = "skills.json"):
        self.skills_db = self._load_skills_database(skills_db_path)

    def _load_skills_database(self, path: str) -> Dict:
        if os.path.exists(path):
            with open(path, "r") as f:
                return json.load(f)
        return {}

    def parse(self, text: str) -> ResumeData:
        """Parse resume text and extract all information."""
        resume_data = ResumeData(raw_text=text)

        resume_data.name = self._extract_name(text)
        resume_data.email = self._extract_email(text)
        resume_data.phone = self._extract_phone(text)
        resume_data.summary = self._extract_summary(text)
        resume_data.education = self._extract_education(text)
        resume_data.experience = self._extract_experience(text)
        resume_data.skills = self._extract_skills(text)

        return resume_data

    def _extract_name(self, text: str) -> str:
        """Extract candidate name using heuristics."""
        lines = text.split("\n")[:10]

        for line in lines:
            line = line.strip()
            if not line or len(line) < 3:
                continue

            if re.match(r"^[A-Z][a-z]+(?:\s+[A-Z][a-z]+){1,3}$", line):
                exclude_words = ["resume", "curriculum", "vitae", "cv", "objective"]
                if not any(word in line.lower() for word in exclude_words):
                    return line

        return ""

    def _extract_email(self, text: str) -> str:
        """Extract email address."""
        email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
        emails = re.findall(email_pattern, text)
        return emails[0] if emails else ""

    def _extract_phone(self, text: str) -> str:
        """Extract phone number."""
        phone_patterns = [
            r"\+?\d{1,3}[-.\s]?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}",
            r"\(\d{3}\)\s?\d{3}[-.]?\d{4}",
            r"\d{3}[-.]\d{3}[-.]\d{4}",
        ]

        phones = []
        for pattern in phone_patterns:
            phones.extend(re.findall(pattern, text))

        cleaned_phones = []
        for phone in phones:
            cleaned = re.sub(r"[^\d+]", "", phone)
            if len(cleaned) >= 10:
                cleaned_phones.append(cleaned)

        return cleaned_phones[0] if cleaned_phones else ""

    def _extract_summary(self, text: str) -> str:
        """Extract professional summary."""
        patterns = [
            r"(?:SUMMARY|PROFILE|OBJECTIVE)[:\s]*(.*?)(?=\n\n|\n[A-Z]{2,}|$)",
        ]
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE | re.DOTALL)
            if match:
                summary = match.group(1).strip()
                if len(summary) > 20:
                    return summary
        return ""

    def _extract_education(self, text: str) -> List[Dict]:
        """Extract education information."""
        education_list = []
        edu_keywords = [
            r"Bachelor",
            r"Master",
            r"PhD",
            r"Diploma",
            r"B\.Tech",
            r"M\.Tech",
        ]

        edu_section_pattern = r"(?:EDUCATION|ACADEMIC QUALIFICATIONS)[:\s]*(.*?)(?=\n\n[A-Z]|\n[A-Z]{2,}\s|$)"
        match = re.search(edu_section_pattern, text, re.IGNORECASE | re.DOTALL)

        if match:
            edu_text = match.group(1)
            lines = edu_text.split("\n")
            current_edu = {}

            for line in lines:
                line = line.strip()
                if not line:
                    continue

                for keyword in edu_keywords:
                    if re.search(keyword, line, re.IGNORECASE):
                        if current_edu:
                            education_list.append(current_edu)
                        current_edu = {"degree": line}
                        break
                else:
                    if current_edu:
                        if re.search(r"\d{4}", line):
                            current_edu["year"] = line
                        elif len(line) > 3:
                            current_edu.setdefault("institution", line)

            if current_edu:
                education_list.append(current_edu)

        return education_list if education_list else [{"degree": "Not specified"}]

    def _extract_experience(self, text: str) -> List[Dict]:
        """Extract work experience."""
        experience_list = []
        exp_section_pattern = r"(?:EXPERIENCE|WORK EXPERIENCE|EMPLOYMENT HISTORY)[:\s]*(.*?)(?=\n\n[A-Z]{2,}|\nEDUCATION|\nPROJECTS|$)"
        match = re.search(exp_section_pattern, text, re.IGNORECASE | re.DOTALL)

        if match:
            exp_text = match.group(1)
            entries = re.split(
                r"\n(?=[A-Z][a-z]+\s+(?:Engineer|Developer|Manager|Analyst|Lead))",
                exp_text,
            )

            for entry in entries:
                entry = entry.strip()
                if len(entry) > 20:
                    lines = entry.split("\n")
                    exp_dict = {
                        "title": lines[0] if lines else "",
                        "description": "\n".join(lines[1:]) if len(lines) > 1 else "",
                    }
                    experience_list.append(exp_dict)

        return experience_list if experience_list else [{"title": "Not specified"}]

    def _extract_skills(self, text: str) -> List[str]:
        """Extract skills using skills database."""
        skills_found = set()
        all_skills = []
        for category, skills in self.skills_db.items():
            all_skills.extend(skills)

        text_lower = text.lower()
        for skill in all_skills:
            if skill.lower() in text_lower:
                skills_found.add(skill)

        return sorted(list(skills_found))
