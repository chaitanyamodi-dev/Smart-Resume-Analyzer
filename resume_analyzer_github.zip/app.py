import io
import os
import traceback
import streamlit as st

from extractor import TextExtractor
from parser import ResumeParser
from matcher import MatchingEngine
from suggestions import SuggestionEngine
from report import generate_report
from utils_text_cleaner import clean_text
from validators import validate_file, validate_job_description

import fitz
import pdfplumber
from docx import Document

# ---------------------------------------------------------------------------
# PREMIUM UI CONFIGURATION
# ---------------------------------------------------------------------------
st.set_page_config(page_title="Smart Resume Analyzer", page_icon="🚀", layout="wide")

PREMIUM_CSS = """
<style>
    /* --- Global Theme Variables --- */
    :root {
        --bg-primary: #0B0F19;
        --bg-card: rgba(30, 41, 59, 0.7);
        --border-color: rgba(255, 255, 255, 0.08);
        --text-main: #F8FAFC;
        --text-muted: #94A3B8;
        --accent-blue: #3B82F6;
        --accent-gradient: linear-gradient(135deg, #3B82F6 0%, #8B5CF6 100%);
        --success: #10B981;
        --warning: #F59E0B;
        --danger: #EF4444;
    }

    .stApp { background-color: var(--bg-primary); color: var(--text-main); font-family: 'Inter', sans-serif; }
    
    /* --- Typography & Headers --- */
    h1, h2, h3 { color: var(--text-main) !important; font-weight: 700; letter-spacing: -0.5px; }
    .stMarkdown p, .stText { color: var(--text-muted); line-height: 1.6; }
    
    /* --- Glassmorphic Cards --- */
    div[data-testid="stVerticalBlock"] > div[style*="flex-direction: column;"] > div[data-testid="stVerticalBlock"] {
        background: var(--bg-card);
        backdrop-filter: blur(12px);
        -webkit-backdrop-filter: blur(12px);
        border: 1px solid var(--border-color);
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 20px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
    }

    /* --- Metrics Styling --- */
    [data-testid="stMetricValue"] { font-size: 2rem !important; color: var(--text-main) !important; font-weight: 600; }
    [data-testid="stMetricLabel"] { color: var(--text-muted) !important; font-size: 0.85rem !important; text-transform: uppercase; letter-spacing: 1px; }

    /* --- Premium Button --- */
    .stButton button {
        background: var(--accent-gradient);
        color: white; border: none; border-radius: 12px; padding: 14px 24px;
        font-weight: 600; font-size: 16px; transition: all 0.3s ease;
        box-shadow: 0 4px 15px rgba(59, 130, 246, 0.3);
    }
    .stButton button:hover { transform: translateY(-2px); box-shadow: 0 6px 20px rgba(59, 130, 246, 0.5); }
    .stButton button:disabled { opacity: 0.5; cursor: not-allowed; transform: none; }

    /* --- File Uploader --- */
    .uploadedFile { background: rgba(15, 23, 42, 0.5); border: 2px dashed var(--border-color); border-radius: 12px; }
    
    /* --- Skill Pills --- */
    .skill-pill { display: inline-block; padding: 6px 14px; border-radius: 20px; font-size: 13px; font-weight: 500; margin: 4px; }
    .pill-matched { background: rgba(16, 185, 129, 0.15); color: #6EE7B7; border: 1px solid rgba(16, 185, 129, 0.3); }
    .pill-missing { background: rgba(239, 68, 68, 0.15); color: #FCA5A5; border: 1px solid rgba(239, 68, 68, 0.3); }

    /* --- Suggestion Cards --- */
    .sug-card { background: var(--bg-card); border-left: 4px solid var(--accent-blue); padding: 16px; border-radius: 0 12px 12px 0; margin-bottom: 12px; }
    .sug-high { border-left-color: var(--danger); }
    .sug-med { border-left-color: var(--warning); }
    .sug-low { border-left-color: var(--accent-blue); }

    /* --- Hide Streamlit Branding --- */
    #MainMenu, footer, header { visibility: hidden; }
    .stDeployButton { display: none; }
</style>
"""
st.markdown(PREMIUM_CSS, unsafe_allow_html=True)


# ---------------------------------------------------------------------------
# CORE LOGIC (Preserved from original)
# ---------------------------------------------------------------------------
def initialize_session_state():
    defaults = {
        "analysis_complete": False,
        "report_paths": {},
        "resume_data": None,
        "match_result": None,
        "suggestions": [],
    }
    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value


@st.cache_data(show_spinner=False)
def extract_text(_file_bytes, file_name):
    file_bytes = bytes(_file_bytes)
    try:
        if file_name.lower().endswith(".pdf"):
            try:
                with fitz.open(stream=file_bytes, filetype="pdf") as doc:
                    text = "\n".join(page.get_text("text") for page in doc)
                    if text and text.strip():
                        return text
            except Exception:
                pass

            try:
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    pages = [page.extract_text() or "" for page in pdf.pages]
                    text = "\n".join(p for p in pages if p)
                    if text and text.strip():
                        return text
            except Exception:
                pass

        elif file_name.lower().endswith(".docx"):
            try:
                file_stream = io.BytesIO(file_bytes)
                doc = Document(file_stream)
                paragraphs = [p.text for p in doc.paragraphs if p.text.strip()]
                text = "\n".join(paragraphs)
                if text and text.strip():
                    return text
            except Exception:
                pass
        return ""
    except Exception:
        return ""


def analyze_resume(uploaded_file, job_description):
    try:
        temp_dir = "temp_uploads"
        os.makedirs(temp_dir, exist_ok=True)
        temp_path = os.path.join(temp_dir, uploaded_file.name)

        with open(temp_path, "wb") as f:
            f.write(uploaded_file.getvalue())

        is_valid, error_msg = validate_file(temp_path)
        if not is_valid:
            st.error(f"⚠️ {error_msg}")
            return None, None, None

        with st.spinner("🔍 Extracting document content..."):
            raw_text = extract_text(uploaded_file.getvalue(), uploaded_file.name)
            if not raw_text or not raw_text.strip():
                st.error("❌ Failed to extract text. Try a simpler PDF/DOCX.")
                return None, None, None
            cleaned_text = clean_text(raw_text)

        with st.spinner("🧠 Parsing entities & skills..."):
            parser = ResumeParser()
            resume_data = parser.parse(cleaned_text)

        with st.spinner("️ Calculating semantic match..."):
            matcher = MatchingEngine()
            match_result = matcher.calculate_match(resume_data, job_description)

        with st.spinner("💡 Generating AI feedback..."):
            suggestion_engine = SuggestionEngine()
            suggestions = suggestion_engine.generate_suggestions(
                match_result, resume_data
            )

        with st.spinner("📝 Preparing export files..."):
            report_paths = generate_report(
                match_result, resume_data, suggestions, format="both"
            )
            st.session_state.report_paths = report_paths

        if os.path.exists(temp_path):
            os.remove(temp_path)
        return resume_data, match_result, suggestions

    except Exception as e:
        st.error(f"⚠️ Analysis failed: {str(e)}")
        st.code(traceback.format_exc())
        return None, None, None


# ---------------------------------------------------------------------------
# PREMIUM RESULTS VIEW
# ---------------------------------------------------------------------------
def show_results():
    if not st.session_state.analysis_complete:
        return

    mr = st.session_state.match_result
    rd = st.session_state.resume_data
    sugs = st.session_state.suggestions

    # Hero Score Section
    score = mr.overall_score
    if score >= 80:
        color, status = "#10B981", "Excellent Match"
    elif score >= 60:
        color, status = "#F59E0B", "Good Match"
    elif score >= 40:
        color, status = "#F97316", "Fair Match"
    else:
        color, status = "#EF4444", "Needs Improvement"

    st.markdown(
        f"""
    <div style="text-align:center; padding: 50px 0; background: linear-gradient(180deg, rgba(30,41,59,0.8) 0%, rgba(11,15,25,0) 100%); 
                border-radius: 24px; border: 1px solid rgba(255,255,255,0.05); margin-bottom: 40px;">
        <h2 style="font-size: 90px; margin: 0; color: {color}; text-shadow: 0 0 40px {color}40;">{score:.1f}%</h2>
        <h3 style="color: var(--text-muted); margin-top: 15px; font-weight: 400; letter-spacing: 2px; text-transform: uppercase;">{status}</h3>
    </div>
    """,
        unsafe_allow_html=True,
    )

    # Metrics Grid
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Skills Match", f"{mr.skills_match_score:.1f}%")
    m2.metric("Semantic Fit", f"{mr.semantic_similarity_score:.1f}%")
    m3.metric("Experience", f"{mr.experience_relevance_score:.1f}%")
    m4.metric("Education", f"{mr.education_match_score:.1f}%")
    m5.metric("Quality", f"{mr.resume_quality_score:.1f}%")

    st.divider()

    # Skills Analysis with Pills
    st.subheader(" Skills Gap Analysis")
    c1, c2 = st.columns([1, 1])

    with c1:
        st.markdown("**✅ Matched Skills**")
        if mr.matched_skills:
            pills = "".join(
                [
                    f'<span class="skill-pill pill-matched">{s}</span>'
                    for s in mr.matched_skills
                ]
            )
            st.markdown(pills, unsafe_allow_html=True)
        else:
            st.info("No matching skills detected.")

    with c2:
        st.markdown("**❌ Missing Skills**")
        if mr.missing_skills:
            pills = "".join(
                [
                    f'<span class="skill-pill pill-missing">{s}</span>'
                    for s in mr.missing_skills
                ]
            )
            st.markdown(pills, unsafe_allow_html=True)
        else:
            st.success("All required skills present!")

    st.divider()

    # Candidate Profile Card
    st.subheader("👤 Extracted Profile")
    p1, p2 = st.columns(2)
    with p1:
        st.markdown(f"**Name:** {rd.name or 'N/A'}")
        st.markdown(f"**Email:** {rd.email or 'N/A'}")
        st.markdown(f"**Phone:** {rd.phone or 'N/A'}")
        if rd.summary:
            st.markdown(f"**Summary:** *{rd.summary[:200]}...*")
    with p2:
        if rd.education and rd.education[0].get("degree") != "Not specified":
            st.markdown(f"**Education:** {rd.education[0]['degree']}")
        if rd.experience and rd.experience[0].get("title") != "Not specified":
            st.markdown(f"**Current Role:** {rd.experience[0]['title']}")

    st.divider()

    # Smart Suggestions
    st.subheader("💡 Actionable Feedback")
    for s in sugs:
        border_class = (
            "sug-high"
            if s.priority == "High"
            else "sug-med"
            if s.priority == "Medium"
            else "sug-low"
        )
        icon = "" if s.priority == "High" else "" if s.priority == "Medium" else "🔵"

        st.markdown(
            f"""
        <div class="sug-card {border_class}">
            <strong>{icon} {s.message}</strong><br>
            <span style="color:var(--text-muted); font-size:14px; margin-top:6px; display:block;">→ {s.action_item}</span>
        </div>
        """,
            unsafe_allow_html=True,
        )

    st.divider()

    # Downloads & Reset
    dl1, dl2 = st.columns(2)
    with dl1:
        if "pdf" in st.session_state.report_paths:
            path = st.session_state.report_paths["pdf"]
            if os.path.exists(path):
                with open(path, "rb") as f:
                    st.download_button(
                        " Download PDF Report",
                        f.read(),
                        file_name=os.path.basename(path),
                        mime="application/pdf",
                        use_container_width=True,
                    )
    with dl2:
        if "csv" in st.session_state.report_paths:
            path = st.session_state.report_paths["csv"]
            if os.path.exists(path):
                with open(path, "rb") as f:
                    st.download_button(
                        " Download CSV Data",
                        f.read(),
                        file_name=os.path.basename(path),
                        mime="text/csv",
                        use_container_width=True,
                    )

    st.markdown("<br>", unsafe_allow_html=True)
    if st.button("🔄 Start New Analysis", use_container_width=True):
        for key in [
            "analysis_complete",
            "resume_data",
            "match_result",
            "suggestions",
            "report_paths",
        ]:
            if key in st.session_state:
                del st.session_state[key]
        st.rerun()


# ---------------------------------------------------------------------------
# MAIN APP ENTRY POINT
# ---------------------------------------------------------------------------
def main():
    initialize_session_state()

    # Header
    col_logo, col_title = st.columns([1, 10])
    with col_title:
        st.title("🚀 Smart Resume Analyzer")
        st.caption("AI-Powered Resume Screening & Optimization Platform")
    st.divider()

    if not st.session_state.analysis_complete:
        # Input Section
        c1, c2 = st.columns([1, 1])

        with c1:
            st.subheader("📂 Upload Resume")
            uploaded_file = st.file_uploader(
                "", type=["pdf", "docx"], label_visibility="collapsed"
            )
            if uploaded_file:
                st.success(f"✅ **{uploaded_file.name}** loaded")
                st.info(f"Size: {uploaded_file.size / 1024:.1f} KB")

        with c2:
            st.subheader("📋 Job Description")
            job_description = st.text_area(
                "",
                height=200,
                placeholder="Paste the full job description here...",
                label_visibility="collapsed",
            )

        st.markdown("<br>", unsafe_allow_html=True)

        center_col = st.columns([3, 4, 3])
        with center_col[1]:
            analyze_btn = st.button(
                "✨ Start Analysis", type="primary", use_container_width=True
            )

        if analyze_btn:
            if not uploaded_file or not job_description:
                st.warning("⚠️ Please upload a resume AND paste a job description.")
            else:
                is_valid_jd, jd_error = validate_job_description(job_description)
                if not is_valid_jd:
                    st.error(f"⚠️ {jd_error}")
                else:
                    resume_data, match_result, suggestions = analyze_resume(
                        uploaded_file, job_description
                    )
                    if resume_data and match_result:
                        st.session_state.resume_data = resume_data
                        st.session_state.match_result = match_result
                        st.session_state.suggestions = suggestions
                        st.session_state.analysis_complete = True
                        st.rerun()
    else:
        show_results()


if __name__ == "__main__":
    main()
