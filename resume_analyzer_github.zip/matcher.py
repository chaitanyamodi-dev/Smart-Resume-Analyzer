"""
Scoring engine: Skills + Semantic + Experience + Education + Quality.
"""

from typing import Dict, List
from dataclasses import dataclass


@dataclass
class MatchResult:
    overall_score: float
    skills_match_score: float
    semantic_similarity_score: float
    experience_relevance_score: float
    education_match_score: float
    resume_quality_score: float
    matched_skills: List[str]
    missing_skills: List[str]
    details: Dict = None


class MatchingEngine:
    def __init__(self):
        self.sentence_model = None
        self._load_models()

    def _load_models(self):
        try:
            from sentence_transformers import SentenceTransformer

            self.sentence_model = SentenceTransformer("all-MiniLM-L6-v2")
        except ImportError:
            print(
                "sentence-transformers not installed. Install with: pip install sentence-transformers"
            )

    def calculate_match(self, resume_data, job_description: str) -> MatchResult:
        jd_skills = self._extract_jd_skills(job_description)
        resume_skills = resume_data.skills

        skills_score = self._calculate_skills_match(resume_skills, jd_skills)
        semantic_score = self._calculate_semantic_similarity(
            resume_data.raw_text, job_description
        )
        experience_score = self._calculate_experience_relevance(
            resume_data.experience, job_description
        )
        education_score = self._calculate_education_match(
            resume_data.education, job_description
        )
        quality_score = self._calculate_resume_quality(resume_data)

        overall_score = (
            skills_score * 0.40
            + semantic_score * 0.30
            + experience_score * 0.15
            + education_score * 0.10
            + quality_score * 0.05
        )

        matched_skills = [s for s in resume_skills if s in jd_skills]
        missing_skills = [s for s in jd_skills if s not in resume_skills]

        return MatchResult(
            overall_score=min(100, max(0, overall_score)),
            skills_match_score=skills_score,
            semantic_similarity_score=semantic_score,
            experience_relevance_score=experience_score,
            education_match_score=education_score,
            resume_quality_score=quality_score,
            matched_skills=matched_skills,
            missing_skills=missing_skills,
            details={"total_required_skills": len(jd_skills)},
        )

    def _extract_jd_skills(self, job_description: str) -> List[str]:
        import json, os

        skills_db_path = "skills.json"
        if os.path.exists(skills_db_path):
            with open(skills_db_path, "r") as f:
                skills_db = json.load(f)
        else:
            skills_db = {}

        all_skills = []
        for category, skills in skills_db.items():
            all_skills.extend([s.lower() for s in skills])

        jd_lower = job_description.lower()
        found_skills = []

        for skill in all_skills:
            if skill in jd_lower:
                for category, skills in skills_db.items():
                    for s in skills:
                        if s.lower() == skill:
                            found_skills.append(s)
                            break

        return list(set(found_skills))

    def _calculate_skills_match(
        self, resume_skills: List[str], jd_skills: List[str]
    ) -> float:
        if not jd_skills:
            return 50.0
        if not resume_skills:
            return 0.0

        resume_set = set(s.lower() for s in resume_skills)
        jd_set = set(s.lower() for s in jd_skills)
        matched = resume_set.intersection(jd_set)

        score = (len(matched) / len(jd_set)) * 100
        return min(100, max(0, score))

    def _calculate_semantic_similarity(self, resume_text: str, jd_text: str) -> float:
        if not self.sentence_model:
            return self._keyword_overlap_score(resume_text, jd_text)

        try:
            from sklearn.metrics.pairwise import cosine_similarity

            resume_embedding = self.sentence_model.encode(
                resume_text[:2000], convert_to_tensor=False
            )
            jd_embedding = self.sentence_model.encode(
                jd_text[:2000], convert_to_tensor=False
            )

            similarity = cosine_similarity(
                resume_embedding.reshape(1, -1), jd_embedding.reshape(1, -1)
            )[0][0]

            return max(0, min(100, similarity * 100))
        except Exception as e:
            print(f"Semantic similarity failed: {e}")
            return self._keyword_overlap_score(resume_text, jd_text)

    def _keyword_overlap_score(self, text1: str, text2: str) -> float:
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        stop_words = {
            "the",
            "and",
            "or",
            "in",
            "on",
            "at",
            "to",
            "for",
            "of",
            "is",
            "are",
        }
        words1 -= stop_words
        words2 -= stop_words

        if not words1 or not words2:
            return 50.0

        overlap = words1.intersection(words2)
        score = (len(overlap) / len(words2)) * 100
        return min(100, max(0, score))

    def _calculate_experience_relevance(
        self, experiences: List[Dict], jd_text: str
    ) -> float:
        if not experiences or experiences[0].get("title") == "Not specified":
            return 30.0

        jd_lower = jd_text.lower()
        role_keywords = [
            "developer",
            "engineer",
            "analyst",
            "manager",
            "lead",
            "architect",
        ]
        score = 0

        for exp in experiences:
            title = exp.get("title", "").lower()
            for keyword in role_keywords:
                if keyword in title and keyword in jd_lower:
                    score += 20
                    break

            desc = exp.get("description", "").lower()
            exp_words = set(desc.split())
            jd_words = set(jd_lower.split())
            if exp_words and jd_words:
                overlap = len(exp_words.intersection(jd_words))
                score += min(30, overlap * 2)

        return min(100, max(0, score))

    def _calculate_education_match(self, education: List[Dict], jd_text: str) -> float:
        if not education or education[0].get("degree") == "Not specified":
            return 40.0

        jd_lower = jd_text.lower()
        edu_keywords = ["bachelor", "master", "phd", "degree", "diploma"]
        score = 0

        for edu in education:
            degree = edu.get("degree", "").lower()
            for keyword in edu_keywords:
                if keyword in degree and keyword in jd_lower:
                    score += 30
                    break

        return min(100, max(0, score))

    def _calculate_resume_quality(self, resume_data) -> float:
        score = 0
        if resume_data.name:
            score += 15
        if resume_data.email:
            score += 10
        if resume_data.phone:
            score += 10
        if resume_data.summary:
            score += 15
        if resume_data.skills:
            score += 20
        if (
            resume_data.experience
            and resume_data.experience[0].get("title") != "Not specified"
        ):
            score += 15
        if (
            resume_data.education
            and resume_data.education[0].get("degree") != "Not specified"
        ):
            score += 15

        # Bonus for measurable achievements
        if resume_data.experience:
            for exp in resume_data.experience:
                desc = exp.get("description", "")
                if any(char.isdigit() for char in desc):
                    score += 5
                    break

        return min(100, max(0, score))
