"""
Input validation utilities.
"""

import os
from typing import Tuple, Optional

MAX_FILE_SIZE_MB = 5
ALLOWED_EXTENSIONS = {".pdf", ".docx"}


def validate_file(file_path: str) -> Tuple[bool, Optional[str]]:
    """Validate uploaded resume file."""
    if not os.path.exists(file_path):
        return False, "File does not exist"

    file_size_mb = os.path.getsize(file_path) / (1024 * 1024)
    if file_size_mb > MAX_FILE_SIZE_MB:
        return (
            False,
            f"File size ({file_size_mb:.2f} MB) exceeds limit of {MAX_FILE_SIZE_MB} MB",
        )

    _, ext = os.path.splitext(file_path)
    if ext.lower() not in ALLOWED_EXTENSIONS:
        return False, f"Unsupported format: {ext}. Allowed: PDF, DOCX"

    return True, None


def validate_job_description(jd_text: str) -> Tuple[bool, Optional[str]]:
    """Validate job description input."""
    if not jd_text or not jd_text.strip():
        return False, "Job description cannot be empty"

    if len(jd_text.strip()) < 50:
        return False, "Job description is too short (min 50 chars)"

    if len(jd_text) > 10000:
        return False, "Job description is too long (max 10,000 chars)"

    return True, None
